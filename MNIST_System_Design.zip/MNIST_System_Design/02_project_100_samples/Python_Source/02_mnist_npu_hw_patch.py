# ==============================================================================
# This code accompanies the book "AI NPU System Design with Python and Verilog".
#
# Copyright (c) 2026 Roger Kim & EdgeChipLab.
# Licensed under the MIT License.
# ==============================================================================


from pathlib import Path

# ============================================================
# 1) Dynamic Path Setting (No Hardcoding)
# ============================================================
try:
    # Get the directory where this script is located
    BASE_DIR = Path(__file__).resolve().parent
except NameError:
    # Use current working directory if running in interactive mode
    BASE_DIR = Path.cwd()

# Define target folders relative to the script location
TARGET_PATHS = [
    BASE_DIR / "MNIST_testset2_trained",    # Master weight storage
    BASE_DIR / "MNIST_VERIFICATION_100"     # 100-sample verification folder
]

print(f"[Info] Base Directory: {BASE_DIR}")

# ============================================================
# 2) Patching Execution Loop
# ============================================================
for target_path in TARGET_PATHS:
    if not target_path.exists():
        print(f"[SKIP] Directory not found: {target_path}")
        continue
    
    print(f"\n>>> Processing Folder: {target_path}")

    w_path = target_path / "conv1_weights.hex"
    b_path = target_path / "conv1_bias.hex"

    # -----------------------------
    # 1) Processing conv1_weights.hex (8-bit to 16-bit Sign-extension)
    # -----------------------------
    if w_path.exists():
        w_lines = w_path.read_text().splitlines()
        w16_lines = []
        for s in w_lines:
            s = s.strip()
            if not s: continue
            v8 = int(s, 16) & 0xFF
            # 8-bit sign -> 16-bit sign-extend
            v16 = (v8 | 0xFF00) if (v8 & 0x80) else v8
            w16_lines.append(f"{v16 & 0xFFFF:04x}")
        
        w_path.write_text("\n".join(w16_lines) + "\n", encoding="utf-8")
        print(f"    [UPDATED] {w_path.name} (Sign-extension complete)")

    # -----------------------------
    # 2) Processing conv1_bias.hex (32-bit to 16-bit Truncation)
    # -----------------------------
    if b_path.exists():
        b_lines = b_path.read_text().splitlines()
        b16_lines = []
        for s in b_lines:
            s = s.strip()
            if not s: continue
            # Keep only lower 16-bits to match Verilog ROM
            v16 = int(s, 16) & 0xFFFF
            b16_lines.append(f"{v16:04x}")
        
        b_path.write_text("\n".join(b16_lines) + "\n", encoding="utf-8")
        print(f"    [UPDATED] {b_path.name} (Truncation complete)")

# ============================================================
# 3) Final Status Message
# ============================================================
print("\n" + "="*60)
print("SUCCESS: Hardware-compatible patching is complete for all folders.")
print(f"CRITICAL: Always use the patched .hex files from:")
print(f"          {TARGET_PATHS[0]}")
print("          as your master reference for Vivado implementation.")
print("="*60)