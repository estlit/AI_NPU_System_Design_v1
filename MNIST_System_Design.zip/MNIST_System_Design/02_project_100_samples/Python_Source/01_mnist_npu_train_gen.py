# ==============================================================================
# This code accompanies the book "AI NPU System Design with Python and Verilog".
#
# Copyright (c) 2026 Roger Kim & EdgeChipLab.
# Licensed under the MIT License.
# ==============================================================================


import os
import numpy as np
from pathlib import Path

import tensorflow as tf
from tensorflow.keras import layers, models, datasets

# ============================================================
# 0) Fixed Verilog Parameters (Do not change)
# ============================================================
IMG_W = 28
K = 3
OUT_W = 26
CHANNELS = 4

SHIFT_CONV = 4
SHIFT_FC   = 0
ACC_BITS   = 16

FEAT_DIM  = 4 * 13 * 13  # 676
NUM_CLASS = 10

# ============================================================
# 1) Dynamic Output Paths (No Hardcoding)
# ============================================================
# Get the directory where this script is located
try:
    BASE_DIR = Path(__file__).resolve().parent
except NameError:
    # Use current working directory if running in Jupyter/Interactive mode
    BASE_DIR = Path.cwd()

# Define subdirectories relative to the script's location
OUT_WB_DIR  = BASE_DIR / "MNIST_testset2_trained"    # For weight/bias storage
OUT_VEC_DIR = BASE_DIR / "MNIST_VERIFICATION_100"    # For 100 verification vectors

# Automatically create directories if they do not exist
OUT_WB_DIR.mkdir(parents=True, exist_ok=True)
OUT_VEC_DIR.mkdir(parents=True, exist_ok=True)

print(f"[Info] Base Directory: {BASE_DIR}")
print(f"[Info] Saving WB to  : {OUT_WB_DIR}")
print(f"[Info] Saving Vec to : {OUT_VEC_DIR}")

# ... (Rest of the functions: wrap16_vec, sat_int8, conv2d_3x3_u8_i8_acc16, etc. remain unchanged) ...

def wrap16_vec(x_int64):
    x = np.bitwise_and(x_int64, 0xFFFF).astype(np.int32)
    x = np.where(x & 0x8000, x - 0x10000, x)
    return x.astype(np.int32)

def sat_int8(x_int32):
    return np.clip(x_int32, -128, 127).astype(np.int8)

def conv2d_3x3_u8_i8_acc16(img_u8_28x28, w_i8_4x3x3, b_i32_4):
    img = img_u8_28x28.astype(np.int32)
    patches = np.zeros((OUT_W * OUT_W, 9), dtype=np.int32)
    idx = 0
    for i in range(OUT_W):
        for j in range(OUT_W):
            patches[idx, :] = img[i:i+3, j:j+3].reshape(-1)
            idx += 1
    w = w_i8_4x3x3.reshape((CHANNELS, 9)).astype(np.int32)
    acc64 = patches.astype(np.int64) @ w.T.astype(np.int64)
    acc64 = acc64 + b_i32_4.astype(np.int64)[None, :]
    acc32 = wrap16_vec(acc64)
    acc_shift = (acc32 >> SHIFT_CONV).astype(np.int32)
    out = sat_int8(acc_shift).T.reshape((CHANNELS, OUT_W, OUT_W))
    return out

def relu_int8(x):
    y = x.astype(np.int16)
    y[y < 0] = 0
    return y.astype(np.int8)

def maxpool2x2_int8(x_4x26x26):
    out = np.zeros((CHANNELS, 13, 13), dtype=np.int8)
    for c in range(CHANNELS):
        for i in range(13):
            for j in range(13):
                out[c, i, j] = np.max(x_4x26x26[c, 2*i:2*i+2, 2*j:2*j+2])
    return out

def flatten_fc(pool_4x13x13):
    vec = np.zeros((FEAT_DIM,), dtype=np.int8)
    idx = 0
    for i in range(13):
        for j in range(13):
            for k in range(4):
                vec[idx] = pool_4x13x13[k, i, j]
                idx += 1
    return vec

def fc_int8(feat_i8_676, W_i8_10x676, B_i32_10):
    feat32 = feat_i8_676.astype(np.int32)
    scores = np.zeros((NUM_CLASS,), dtype=np.int32)
    for k in range(NUM_CLASS):
        acc = int(np.dot(W_i8_10x676[k].astype(np.int32), feat32)) + int(B_i32_10[k])
        if SHIFT_FC != 0:
            acc >>= SHIFT_FC
        scores[k] = acc
    return scores

def argmax_digit(scores):
    return int(np.argmax(scores))

def npu_predict_one(img_u8, cw_i8, cb_i32, fw_i8, fb_i32):
    conv = conv2d_3x3_u8_i8_acc16(img_u8, cw_i8, cb_i32)
    pool = maxpool2x2_int8(relu_int8(conv))
    feat = flatten_fc(pool)
    scores = fc_int8(feat, fw_i8, fb_i32)
    return argmax_digit(scores)

def quantize_int8(fp, target_max):
    maxabs = float(np.max(np.abs(fp)))
    scale = target_max / max(1e-8, maxabs)
    q = np.clip(np.round(fp * scale), -128, 127).astype(np.int8)
    return q, scale

def save_i8_as_u8_hex(path: Path, arr_i8):
    with open(path, "w") as f:
        for v in np.asarray(arr_i8).flatten():
            f.write(f"{int(v) & 0xFF:02x}\n")

def save_i32_hex(path: Path, arr_i32):
    with open(path, "w") as f:
        for v in np.asarray(arr_i32).flatten():
            f.write(f"{int(v) & 0xFFFFFFFF:08x}\n")

def save_image_hex(path: Path, img_u8_28x28):
    with open(path, "w") as f:
        for i in range(28):
            for j in range(28):
                f.write(f"{int(img_u8_28x28[i,j]) & 0xFF:02x}\n")

def save_u4_hex(path: Path, v: int):
    with open(path, "w") as f:
        f.write(f"{int(v) & 0xF:x}\n")

def main():
    # (A) Load MNIST Dataset
    (train_x, train_y), (test_x, test_y) = datasets.mnist.load_data()
    x_train = train_x.reshape((-1,28,28,1)).astype(np.float32)
    x_test  = test_x.reshape((-1,28,28,1)).astype(np.float32)

    # (B) Enhanced Model Training
    print("\n[1] Train float model (stronger) ...")
    model = models.Sequential([
        layers.Conv2D(CHANNELS, (3,3), activation='relu', input_shape=(28,28,1)),
        layers.MaxPooling2D((2,2)),
        layers.Flatten(),
        layers.Dense(NUM_CLASS)
    ])
    model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=2e-5),
                  loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
                  metrics=['accuracy'])
    callbacks = [
        tf.keras.callbacks.ReduceLROnPlateau(monitor="loss", factor=0.5, patience=2, min_lr=1e-6, verbose=1),
        tf.keras.callbacks.EarlyStopping(monitor="loss", patience=6, restore_best_weights=True, verbose=1)
    ]
    model.fit(x_train, train_y, epochs=30, batch_size=128, callbacks=callbacks, verbose=1)

    # (C) Weight Extraction
    print("\n[2] Extract weights ...")
    k_conv_w, k_conv_b = model.layers[0].get_weights()
    k_fc_w,   k_fc_b   = model.layers[3].get_weights()
    conv_w_fp = np.transpose(k_conv_w, (3,0,1,2)).reshape((CHANNELS,3,3))
    fc_w_fp   = np.transpose(k_fc_w, (1,0))

    # (D) Dense Quantization Candidate Search
    print("\n[3] Search quant scales (dense) + bias_mul ...")
    cand_conv = [3, 5, 7, 9, 11, 15]
    cand_fc   = [15, 23, 31, 39, 47, 63]
    cand_bias_mul = [0.5, 1.0, 1.5, 2.0]
    EVAL_N = 2000
    imgs_eval = test_x[:EVAL_N].astype(np.uint8)
    y_eval = test_y[:EVAL_N].astype(int)
    best_acc, best_cfg = -1.0, None

    for tc in cand_conv:
        cw_i8, cscale = quantize_int8(conv_w_fp, tc)
        for tfc in cand_fc:
            fw_i8, fscale = quantize_int8(fc_w_fp, tfc)
            for bias_mul in cand_bias_mul:
                cb_i32 = np.round(k_conv_b * cscale * bias_mul).astype(np.int32)
                fb_i32 = np.round(k_fc_b   * fscale).astype(np.int32)
                correct = 0
                for i in range(EVAL_N):
                    pred = npu_predict_one(imgs_eval[i], cw_i8, cb_i32, fw_i8, fb_i32)
                    if pred == y_eval[i]: correct += 1
                acc = correct / EVAL_N
                print(f"  conv={tc:>2}, fc={tfc:>2}, bias_mul={bias_mul:<3} -> acc={acc:.4f}")
                if acc > best_acc:
                    best_acc, best_cfg = acc, (tc, tfc, bias_mul, cw_i8, cb_i32, fw_i8, fb_i32)

    tc, tfc, bias_mul, cw_i8, cb_i32, fw_i8, fb_i32 = best_cfg
    print(f"\n[4] BEST quantization: CONV_MAX={tc}, FC_MAX={tfc}, bias_mul={bias_mul}, acc={best_acc}")

    # (E) Save Weights
    print("\n[5] Save trained weights/bias ...")
    save_i8_as_u8_hex(OUT_WB_DIR / "conv1_weights.hex", cw_i8)
    save_i32_hex(OUT_WB_DIR / "conv1_bias.hex", cb_i32)
    save_i8_as_u8_hex(OUT_WB_DIR / "fc_weights.hex", fw_i8)
    save_i32_hex(OUT_WB_DIR / "fc_bias.hex", fb_i32)

    # (F) Generate Vectors
    print("\n[6] Generate 100 verification vectors ...")
    save_i8_as_u8_hex(OUT_VEC_DIR / "conv1_weights.hex", cw_i8)
    save_i32_hex(OUT_VEC_DIR / "conv1_bias.hex", cb_i32)
    save_i8_as_u8_hex(OUT_VEC_DIR / "fc_weights.hex", fw_i8)
    save_i32_hex(OUT_VEC_DIR / "fc_bias.hex", fb_i32)

    list_path = OUT_VEC_DIR / "test_list.txt"
    with open(list_path, "w") as lf:
        for i in range(100):
            img, label = test_x[i].astype(np.uint8), int(test_y[i])
            pred = npu_predict_one(img, cw_i8, cb_i32, fw_i8, fb_i32)
            save_image_hex(OUT_VEC_DIR / f"test_{i:03d}_input.hex", img)
            save_u4_hex(OUT_VEC_DIR / f"test_{i:03d}_golden.hex", pred)
            lf.write(f"test_{i:03d}_input.hex,{pred}\n")
    print("\n=== SUMMARY ===")
    print(f"Results saved in: {BASE_DIR}")
    print("=== DONE ===")

if __name__ == "__main__":
    main()