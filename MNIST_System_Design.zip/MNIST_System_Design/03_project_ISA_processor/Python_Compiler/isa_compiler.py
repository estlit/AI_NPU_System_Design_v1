# ============================================================
# isa_compiler.py (Final Production Version)
# - Purpose: Translates .isa DSL to 16-bit .hex machine code
# - Feature: Generates detailed mapping report with DESCRIPTIONS
# - Design: Relative path-based for high portability
# ============================================================

import os
import sys
from datetime import datetime

# ----------------------------
# NPU Opcodes (Matches hardware opcode_defs.sv)
# ----------------------------
OPCODES = {
    "OP_START":     0x01,
    "OP_WAIT_CONV": 0x02,
    "OP_MODE_FC":   0x03,
    "OP_WAIT_FC":   0x04,
    "OP_CLEAR":     0x05,
    "OP_INC_IDX":   0x06,
    "OP_LOOP":      0x07,
    "OP_RESET":     0x08,
    "OP_SLEEP":     0x09,
    "OP_TRACE":     0x0A,
    "OP_HALT":      0x0F,
}

# DSL Configuration
VALID_DSL = {"RUN_MNIST", "SLEEP", "TRACE_ON", "PROFILE"}
DEFAULT_NUM_TESTS = 10

def inst_hex(op, imm):
    """Combines 8-bit opcode and 8-bit immediate into a 16-bit hex string."""
    return f"{((op & 0xFF) << 8 | (imm & 0xFF)):04x}"

def ensure_dir(path):
    """Ensures the directory exists for output files."""
    if path and not os.path.exists(path):
        os.makedirs(path, exist_ok=True)

def find_isa_path():
    """Resolves path priority: 1. CLI Argument, 2. Script Directory, 3. CWD."""
    if len(sys.argv) >= 2:
        p = sys.argv[1]
        if os.path.isfile(p):
            return os.path.abspath(p)

    # Resolve based on script location (Relative Path Support)
    script_dir = os.path.dirname(os.path.abspath(__file__))
    p = os.path.join(script_dir, "program.isa")
    if os.path.isfile(p):
        return p

    p = os.path.join(os.getcwd(), "program.isa")
    if os.path.isfile(p):
        return os.path.abspath(p)

    return os.path.join(script_dir, "program.isa")

def write_template_isa(path):
    """Writes a default program.isa if none is found."""
    ensure_dir(os.path.dirname(path))
    tmpl = (
        "# program.isa (template)\n"
        "# Define your high-level inference flow here\n"
        "RUN_MNIST\n"
        "SLEEP 100\n"
        "PROFILE\n"
    )
    with open(path, "w", encoding="utf-8") as f:
        f.write(tmpl)

def main():
    isa_path = find_isa_path()
    out_dir = os.path.dirname(isa_path)

    # Output file definitions
    asm_path = os.path.join(out_dir, "program.asm")
    hex_path = os.path.join(out_dir, "program.hex")
    rpt_path = os.path.join(out_dir, "compile_report.txt")

    if not os.path.isfile(isa_path):
        print(f"[WARN] ISA source not found. Creating template: {isa_path}")
        write_template_isa(isa_path)

    # Read and clean ISA source lines
    with open(isa_path, "r", encoding="utf-8") as f:
        dsl_lines = [l.strip() for l in f if l.strip() and not l.strip().startswith(("#", "//"))]

    sleep_val, trace_on, profile_on, run_req = 0, False, False, False

    for line in dsl_lines:
        tokens = line.split()
        cmd = tokens[0]
        if cmd not in VALID_DSL:
            raise SystemExit(f"[ERROR] Invalid DSL command: {cmd}")
        
        if cmd == "RUN_MNIST": run_req = True
        elif cmd == "TRACE_ON": trace_on = True
        elif cmd == "PROFILE": profile_on = True
        elif cmd == "SLEEP":
            if len(tokens) == 2: sleep_val = int(tokens[1]) & 0xFF

    if not run_req:
        raise SystemExit("[ERROR] RUN_MNIST command is required.")
    
    # PROFILE mode automatically enables TRACE markers
    if profile_on: trace_on = True

    # --- Schedule Hardware Commands with Descriptions ---
    # Format: (Mnemonic, Immediate, Description)
    asm = []
    asm.append(("OP_RESET", 0, "Hard reset NPU state machines"))
    asm.append(("OP_CLEAR", 0, "Clear internal accumulators and buffers"))
    
    if trace_on: 
        asm.append(("OP_TRACE", 0x01, "MARKER: System initialization complete"))
    
    asm.append(("OP_START", 0, "Kick-off Convolution layer processing"))
    asm.append(("OP_WAIT_CONV", 0, "Wait for Convolution engine to finish"))
    
    if trace_on: 
        asm.append(("OP_TRACE", 0x02, "MARKER: Conv layer execution done"))

    if sleep_val > 0: 
        asm.append(("OP_SLEEP", sleep_val, f"Delay for {sleep_val} cycles for stability"))

    asm.append(("OP_MODE_FC", 0, "Switch NPU data path to Fully-Connected mode"))
    
    if trace_on: 
        asm.append(("OP_TRACE", 0x03, "MARKER: FC mode switch complete"))
    
    asm.append(("OP_WAIT_FC", 0, "Wait for Fully-Connected layer to finish"))
    
    if trace_on: 
        asm.append(("OP_TRACE", 0x04, "MARKER: Inference sequence finished"))
    
    asm.append(("OP_INC_IDX", 0, "Increment image index for next inference"))
    asm.append(("OP_LOOP", 0, "Jump back to START if index < NUM_TESTS"))
    asm.append(("OP_HALT", 0, "Stop execution and enter idle state"))

    # Output 1: Assembly View (.asm)
    with open(asm_path, "w", encoding="utf-8") as f:
        f.write("// Auto-generated NPU Assembly\n")
        f.write(f"// TRACE={trace_on}  PROFILE={profile_on}\n\n")
        for op, imm, desc in asm:
            f.write(f"{op:15s} 0x{imm:02x}\n")

    # Output 2: Machine Code (.hex) for $readmemh
    with open(hex_path, "w", encoding="utf-8") as f:
        f.write("// NPU Machine Code (program.hex)\n")
        f.write("// Format: [8-bit Opcode][8-bit Immediate]\n\n")
        for op, imm, desc in asm:
            f.write(f"{inst_hex(OPCODES[op], imm)}  // {op} {imm}\n")

    # Output 3: Comprehensive Compilation Report
    with open(rpt_path, "w", encoding="utf-8") as f:
        f.write("NPU COMPILER REPORT\n" + "="*20 + "\n")
        f.write(f"Timestamp: {datetime.now()}\n")
        f.write(f"Input ISA: {isa_path}\n\n")
        f.write("DSL CONFIGURATION:\n")
        f.write(f" - RUN_MNIST : {run_req}\n - SLEEP     : {sleep_val}\n")
        f.write(f" - TRACE_ON  : {trace_on}\n - PROFILE   : {profile_on}\n\n")
        
        f.write("INSTRUCTION MAPPING (For Hardware Debugging)\n")
        f.write("-" * 90 + "\n")
        f.write(f"{'ADDR':<6} | {'MNEMONIC':<15} | {'HEX':<8} | {'DESCRIPTION'}\n")
        f.write("-" * 90 + "\n")
        for i, (op, imm, desc) in enumerate(asm):
            hex_val = inst_hex(OPCODES[op], imm)
            f.write(f"0x{i:02x}   | {op:<15} | 0x{hex_val:<6} | {desc}\n")
        f.write("-" * 90 + "\n")
        f.write("\nNote: Sample count (NUM_TESTS) is controlled via Verilog parameters.\n")

    # Console Summary
    print("\n" + "="*40)
    print(" NPU COMPILATION SUCCESSFUL")
    print("="*40)
    print(f" Source   : {os.path.basename(isa_path)}")
    print(f" Hex Out  : {os.path.basename(hex_path)}")
    print(f" Profile  : {'ON' if profile_on else 'OFF'}")
    print(f" Sleep    : {sleep_val} cycles")
    print("="*40 + "\n")

if __name__ == "__main__":
    main()