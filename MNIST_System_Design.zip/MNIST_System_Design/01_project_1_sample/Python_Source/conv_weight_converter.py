# ==============================================================================
# This code accompanies the book "AI NPU System Design with Python and Verilog".
#
# Copyright (c) 2026 Roger Kim & EdgeChipLab.
# Licensed under the MIT License.
# ==============================================================================


# conv1_export_hex.py
import os
import numpy as np
# ----------------------------------------------------
# Global Settings: Input/Output Directory (automatically set)
# ----------------------------------------------------
try:
    # When running as a .py file, use the location of the file.
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
except NameError:
    # Use the current working path in Jupyter Notebook, etc.
    BASE_DIR = os.getcwd()

os.makedirs(BASE_DIR, exist_ok=True)
print(f"[Info] Current Work Directory: {BASE_DIR}")

# 1) NPY load
weights = np.load(os.path.join(BASE_DIR, "conv1_weights_i8.npy")).astype(np.int8)
bias    = np.load(os.path.join(BASE_DIR, "conv1_bias_i32.npy")).astype(np.int32)

print("weights shape:", weights.shape, "dtype:", weights.dtype)  # (4,3,3), int8
print("bias shape   :", bias.shape,    "dtype:", bias.dtype)     # (4,),   int32

# 2) Create conv1_weights.hex
# Flatten order: p (channel) → r (row) → c (column)
# In TB, it can be read as addr = p*9 + r*3 + c,
# Or we will directly place it in weights_tb[p][r][c] with triple for

weights_hex_path = os.path.join(BASE_DIR, "conv1_weights.hex")
with open(weights_hex_path, "w") as f:
    for p in range(weights.shape[0]):      # 0..3
        for r in range(weights.shape[1]):  # 0..2
            for c in range(weights.shape[2]):  # 0..2
                v = int(weights[p, r, c])      # -128..127
                v_u8 = v & 0xFF                # 2's complement 8bit
                f.write(f"{v_u8:02x}\n")
print("[SAVE] conv1_weights.hex ->", weights_hex_path)

# 3) Create conv1_bias.hex (cut to 16bit and use)
# Since the current systolic port is 16bit bias_in[15:0],
# Python's int32 bias uses only the lower 16 bits. (The range is small, so it goes in as is)

bias_hex_path = os.path.join(BASE_DIR, "conv1_bias.hex")
with open(bias_hex_path, "w") as f:
    for p in range(bias.shape[0]):   # 4
        v = int(bias[p])
        v_u16 = v & 0xFFFF
        f.write(f"{v_u16:04x}\n")
print("[SAVE] conv1_bias.hex ->", bias_hex_path)
print("\n=== Weight conversion to Hex completed successfully ===")