# ==============================================================================
# This code accompanies the book "AI NPU System Design with Python and Verilog".
#
# Copyright (c) 2026 Roger Kim & EdgeChipLab.
# Licensed under the MIT License.
# ==============================================================================


import os
import numpy as np

# ----------------------------------------------------
# Global Settings: Input/Output Directory (automatically set)
# ----------------------------------------------------
try:
    # When running as a .py file, use the location of the file.
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
except NameError:
    # Use the current working path in Jupyter Notebook, etc.
    BASE_DIR = os.getcwd()

os.makedirs(BASE_DIR, exist_ok=True)
print(f"[Info] Current Work Directory: {BASE_DIR}")

# Image and Conv1 settings
IMG_W = 28
K = 3
OUT_W = IMG_W - K + 1      # 26
CHANNELS = 4
SHIFT_CONV = 4             # For adjusting Conv output scale (tuning if necessary)

# FC settings
FEAT_DIM = 4 * 13 * 13     # 4 x 13 x 13 = 676
NUM_CLASS = 10
SHIFT_FC = 0               # Adjust FC output scale when needed (now 0)


# ----------------------------------------------------
# 1) Conv1: int8-based golden model
# ----------------------------------------------------
def conv1_int8(input_img_u8, weights_i8, bias_i32):
    """
    input_img_u8 : (28, 28) uint8      - ROM 이미지와 동일
    weights_i8   : (4, 3, 3) int8      - Conv1 weight
    bias_i32     : (4,) int32          - Conv1 bias
    return       : (4, 26, 26) int8    - Conv1 출력 feature map
    """
    assert input_img_u8.shape == (IMG_W, IMG_W)
    assert weights_i8.shape   == (CHANNELS, K, K)
    assert bias_i32.shape     == (CHANNELS,)

    conv_out = np.zeros((CHANNELS, OUT_W, OUT_W), dtype=np.int8)

    # uint8 -> Cast to int32 (use 0~255 as is)
    img = input_img_u8.astype(np.int32)

    for p in range(CHANNELS):
        w = weights_i8[p].astype(np.int32)   # (3,3)
        b = np.int32(bias_i32[p])

        for i in range(OUT_W):
            for j in range(OUT_W):
                acc = b
                for r in range(K):
                    for c in range(K):
                        a  = img[i + r, j + c]   # 0~255
                        wt = w[r, c]             # -128~127
                        acc += a * wt            # int32 accumulation

                # Scale down (shift SHIFT_CONV bit right)
                acc_shift = acc >> SHIFT_CONV

                # Clipping to int8
                if acc_shift > 127:
                    acc_shift = 127
                elif acc_shift < -128:
                    acc_shift = -128

                conv_out[p, i, j] = np.int8(acc_shift)

    return conv_out


# ----------------------------------------------------
# 2) ReLU: negative -> 0
# ----------------------------------------------------
def relu_int8(conv_out):
    """
    conv_out : (4, H, W) int8
    return   : (4, H, W) int8
    """
    relu_out = conv_out.astype(np.int16)
    relu_out[relu_out < 0] = 0
    return relu_out.astype(np.int8)


# ----------------------------------------------------
# 3) MaxPool 2x2, stride 2
# ----------------------------------------------------
def maxpool2x2_int8(relu_out):
    """
    relu_out : (4, 26, 26) int8
    return   : (4, 13, 13) int8
    """
    C, H, W = relu_out.shape
    assert (C, H, W) == (CHANNELS, 26, 26)
    out_h, out_w = H // 2, W // 2   # 13x13

    pool_out = np.zeros((C, out_h, out_w), dtype=np.int8)
    for p in range(C):
        for i in range(out_h):
            for j in range(out_w):
                block = relu_out[p, 2*i:2*i+2, 2*j:2*j+2]
                pool_out[p, i, j] = np.max(block)
    return pool_out


# ----------------------------------------------------
# 4) Flatten → FC input vector generation
#    pool_out (4,13,13) -> fc_input (676,)
# ----------------------------------------------------
def flatten_pool_to_fc_input(pool_out_i8):
    """
    pool_out_i8 : (4, 13, 13) int8
    return      : (676,) int8
    flatten 순서:
      addr = ((i * 13) + j) * 4 + k
      (row i, col j, channel k 순서) 와 동일
    """
    C, H, W = pool_out_i8.shape
    assert (C, H, W) == (CHANNELS, 13, 13)

    fc_input = np.zeros(FEAT_DIM, dtype=np.int8)
    idx = 0
    for i in range(H):
        for j in range(W):
            for k in range(C):
                fc_input[idx] = pool_out_i8[k, i, j]
                idx += 1
    return fc_input


# ----------------------------------------------------
# 5) FC: int8 입력, int8 weight, int32 bias → int32 score
# ----------------------------------------------------
def fc_int8(feat_i8, W_i8, B_i32):
    """
    feat_i8 : (676,) int8
    W_i8    : (10, 676) int8
    B_i32   : (10,) int32
    return  : scores(10,) int32
    """
    assert feat_i8.shape == (FEAT_DIM,)
    assert W_i8.shape   == (NUM_CLASS, FEAT_DIM)
    assert B_i32.shape  == (NUM_CLASS,)

    feat32 = feat_i8.astype(np.int32)
    scores = np.zeros(NUM_CLASS, dtype=np.int32)

    for k in range(NUM_CLASS):
        w32 = W_i8[k].astype(np.int32)
        acc = np.dot(w32, feat32) + np.int32(B_i32[k])
        if SHIFT_FC != 0:
            acc = acc >> SHIFT_FC
        scores[k] = acc

    return scores


# ----------------------------------------------------
# 6) Argmax: final predicted digit (0~9)
# ----------------------------------------------------
def argmax_digit(scores_i32):
    """
    scores_i32 : (10,) int32
    return     : pred (0~9, Python int)
    """
    assert scores_i32.shape == (NUM_CLASS,)
    pred = int(np.argmax(scores_i32))
    return pred


# ----------------------------------------------------
# 7) Common storage functions (NPY / TXT / HEX)
# ----------------------------------------------------
def save_array_npy(name, arr):
    path = os.path.join(BASE_DIR, f"{name}.npy")
    np.save(path, arr)
    print(f"[SAVE] {path}")

def save_array_txt(name, arr):
    path = os.path.join(BASE_DIR, f"{name}.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"# shape: {arr.shape}, dtype: {arr.dtype}\n")
        f.write(str(arr))
    print(f"[SAVE] {path}")


# ---- HEX for Verilog: Input Image ----
def save_image_hex(name, img_u8):
    """
    img_u8 : (28,28) uint8
    flatten 순서: addr = i*28 + j
    """
    path = os.path.join(BASE_DIR, f"{name}.hex")
    with open(path, "w") as f:
        for addr in range(IMG_W * IMG_W):
            i = addr // IMG_W
            j = addr %  IMG_W
            val = int(img_u8[i, j])       # 0~255
            f.write(f"{val:02x}\n")
    print(f"[SAVE] {path}")


# ---- HEX for Verilog: Conv1 result (★ Modified to 16bit version) ----
def save_conv_hex(name, conv_i8):
    """
    conv_i8 : (4,26,26) int8
    flatten 순서:
      addr = ((i * 26) + j) * 4 + k
    각 값(-128~127)을 16bit로 sign-extend 해서 4자리 hex (0000~ffff)로 저장
    """
    path = os.path.join(BASE_DIR, f"{name}.hex")
    C, H, W = conv_i8.shape

    with open(path, "w") as f:
        for i in range(H):          # row
            for j in range(W):      # col
                for k in range(C):  # channel
                    v = int(conv_i8[k, i, j])   # -128 ~ 127
                    v16 = v & 0xFFFF            # 16bit 2's complement
                    f.write(f"{v16:04x}\n")
    print(f"[SAVE] {path}")


# ---- HEX for Verilog: Pool results (★ Modified to 16bit version) ----
def save_pool_hex(name, pool_i8):
    """
    pool_i8 : (4,13,13) int8
    flatten 순서:
      addr = ((i * 13) + j) * 4 + k
    각 값(-128~127)을 16bit로 sign-extend 해서 4자리 hex로 저장
    """
    path = os.path.join(BASE_DIR, f"{name}.hex")
    C, H, W = pool_i8.shape

    with open(path, "w") as f:
        for i in range(H):
            for j in range(W):
                for k in range(C):
                    v = int(pool_i8[k, i, j])   # -128 ~ 127
                    v16 = v & 0xFFFF
                    f.write(f"{v16:04x}\n")
    print(f"[SAVE] {path}")


# ---- HEX for Verilog: FC input ----
def save_fc_input_hex(name, fc_input_i8):
    """
    fc_input_i8 : (676,) int8
    addr = 0..675 (위 flatten 순서와 동일)
    """
    path = os.path.join(BASE_DIR, f"{name}.hex")
    assert fc_input_i8.shape == (FEAT_DIM,)
    with open(path, "w") as f:
        for idx in range(FEAT_DIM):
            v = int(fc_input_i8[idx])
            v_u8 = v & 0xFF
            f.write(f"{v_u8:02x}\n")
    print(f"[SAVE] {path}")


# ---- Verilog용 HEX: FC weight ----
def save_fc_weights_hex(name, W_i8):
    """
    W_i8 : (10, 676) int8
    flatten 순서:
      addr = k*676 + i
      (k: class 0~9, i: feature index 0~675)
    """
    path = os.path.join(BASE_DIR, f"{name}.hex")
    assert W_i8.shape == (NUM_CLASS, FEAT_DIM)

    with open(path, "w") as f:
        for k in range(NUM_CLASS):
            for i in range(FEAT_DIM):
                v = int(W_i8[k, i])
                v_u8 = v & 0xFF
                f.write(f"{v_u8:02x}\n")
    print(f"[SAVE] {path}")


# ---- Verilog용 HEX: FC bias ----
def save_fc_bias_hex(name, B_i32):
    """
    B_i32 : (10,) int32
    한 줄 당 32bit 2의 보수 hex (8자리)
    """
    path = os.path.join(BASE_DIR, f"{name}.hex")
    assert B_i32.shape == (NUM_CLASS,)

    with open(path, "w") as f:
        for k in range(NUM_CLASS):
            v = int(B_i32[k])
            v_u32 = v & 0xFFFFFFFF
            f.write(f"{v_u32:08x}\n")
    print(f"[SAVE] {path}")


# ---- HEX for Verilog: FC score (optional) ----
def save_fc_scores_hex(name, scores_i32):
    """
    scores_i32 : (10,) int32
    """
    path = os.path.join(BASE_DIR, f"{name}.hex")
    assert scores_i32.shape == (NUM_CLASS,)

    with open(path, "w") as f:
        for k in range(NUM_CLASS):
            v = int(scores_i32[k])
            v_u32 = v & 0xFFFFFFFF
            f.write(f"{v_u32:08x}\n")
    print(f"[SAVE] {path}")


# ---- HEX for Verilog: Argmax result (optional) ----
def save_fc_argmax_hex(name, pred_digit):
    """
    pred_digit : 0~9 (int)
    4bit unsigned -> 한 자리 hex로 저장
    """
    path = os.path.join(BASE_DIR, f"{name}.hex")
    with open(path, "w") as f:
        f.write(f"{pred_digit:x}\n")
    print(f"[SAVE] {path}")


# =====================================================
# Main: Full pipeline test (Conv1 → ReLU → Pool → FC → Argmax)
# =====================================================
if __name__ == "__main__":
    np.random.seed(0)

    # (1) Input image (currently random, later replaced by MNIST)
    input_img = np.random.randint(0, 256, size=(IMG_W, IMG_W), dtype=np.uint8)

    # (2) Conv1 weight / bias (currently random, replaced with learning values ​​later)
    conv1_weights = np.random.randint(-3, 4, size=(CHANNELS, K, K), dtype=np.int8)
    conv1_bias    = np.random.randint(-20, 21, size=(CHANNELS,), dtype=np.int32)

    # (3) Conv → ReLU → Pool
    conv_out = conv1_int8(input_img, conv1_weights, conv1_bias)
    relu_out = relu_int8(conv_out)
    pool_out = maxpool2x2_int8(relu_out)

    # (4) FC input generation (Flatten)
    fc_input = flatten_pool_to_fc_input(pool_out)

    # (5) FC weight/bias (currently random)
    fc_weights = np.random.randint(-4, 5, size=(NUM_CLASS, FEAT_DIM), dtype=np.int8)
    fc_bias    = np.random.randint(-100, 101, size=(NUM_CLASS,), dtype=np.int32)

    # (6) FC operation + Argmax
    fc_scores = fc_int8(fc_input, fc_weights, fc_bias)
    pred_digit = argmax_digit(fc_scores)

    # ----------------- Shape/Type Output -----------------
    print("input_img      :", input_img.shape, input_img.dtype)
    print("conv1_weights  :", conv1_weights.shape, conv1_weights.dtype)
    print("conv1_bias     :", conv1_bias.shape, conv1_bias.dtype)
    print("conv_out       :", conv_out.shape, conv_out.dtype)
    print("relu_out       :", relu_out.shape, relu_out.dtype)
    print("pool_out       :", pool_out.shape, pool_out.dtype)
    print("fc_input       :", fc_input.shape, fc_input.dtype)
    print("fc_weights     :", fc_weights.shape, fc_weights.dtype)
    print("fc_bias        :", fc_bias.shape, fc_bias.dtype)
    print("fc_scores      :", fc_scores.shape, fc_scores.dtype)
    print("predicted digit:", pred_digit)

    # ----------------- Save NPY -----------------
    save_array_npy("input_img_u8",        input_img)
    save_array_npy("conv1_weights_i8",    conv1_weights)
    save_array_npy("conv1_bias_i32",      conv1_bias)
    save_array_npy("conv1_out_i8",        conv_out)
    save_array_npy("conv1_relu_out_i8",   relu_out)
    save_array_npy("conv1_pool_out_i8",   pool_out)

    save_array_npy("fc_input_i8",         fc_input)
    save_array_npy("fc_weights_i8",       fc_weights)
    save_array_npy("fc_bias_i32",         fc_bias)
    save_array_npy("fc_scores_i32",       fc_scores)
    save_array_npy("fc_argmax_u1",        np.array(pred_digit, dtype=np.uint8))

    # ----------------- HEX storage (for Verilog) -----------------
    save_image_hex("input_img",           input_img)
    save_conv_hex("conv1_out",            conv_out)       # 16bit hex (0048, fff2 ...)
    save_pool_hex("conv1_pool_out",       pool_out)       # 16bit hex

    save_fc_input_hex("fc_input",         fc_input)
    save_fc_weights_hex("fc_weights",     fc_weights)
    save_fc_bias_hex("fc_bias",           fc_bias)
    save_fc_scores_hex("fc_scores",       fc_scores)
    save_fc_argmax_hex("fc_argmax",       pred_digit)

print("\n=== All pipeline data saved successfully ===")